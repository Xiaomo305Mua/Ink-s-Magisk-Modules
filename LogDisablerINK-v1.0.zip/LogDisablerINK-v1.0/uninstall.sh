#!/system/bin/sh

chattr -i "/data/adb/lspd/log" 2>/dev/null
chattr -i "/data/adb/lspd/log.old" 2>/dev/null

umount "/data/cache/magisk.log" 2>/dev/null

chmod 777 "/data/adb/lspd/log" 2>/dev/null
chmod 755 "/data/adb/lspd/log.old" 2>/dev/null
chmod 666 "/data/cache/magisk.log" 2>/dev/null