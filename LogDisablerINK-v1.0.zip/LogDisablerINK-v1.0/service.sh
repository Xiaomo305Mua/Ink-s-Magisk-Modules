#!/system/bin/sh

LSP_LOG="/data/adb/lspd/log"
LSP_LOG_OLD="/data/adb/lspd/log.old"

MAGISK_LOG="/data/cache/magisk.log"

rm -rf "$LSP_LOG"/* "$LSP_LOG_OLD"/* "$MAGISK_LOG" 2>/dev/null

chattr +i "$LSP_LOG" "$LSP_LOG_OLD" 2>/dev/null
mount -o bind /dev/null "$MAGISK_LOG" 2>/dev/null

chmod 000 "$LSP_LOG" "$LSP_LOG_OLD" "$MAGISK_LOG" 2>/dev/null